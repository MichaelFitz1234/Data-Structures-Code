public class HuffmanNode {
    private Character charVal;
    private Integer frequency;
    private HuffmanNode rightChild;
    private HuffmanNode leftChild;

    /**
     * constuctor of noes
     * @param charVal each node has a character
     * @param frequency how often it occurs
     * @param rightChild the right child it points to
     * @param leftChild left child it points too
     */
    public HuffmanNode(Character charVal, Integer frequency, HuffmanNode rightChild, HuffmanNode leftChild) {
        this.charVal = charVal;
        this.frequency = frequency;
        this.rightChild = rightChild;
        this.leftChild = leftChild;
    }
    //gets the character value
    public Character getChar(){
        return charVal;
    }
    //gets the frequency
    public Integer getFrequency(){
        return frequency;
    }
    //gets the left child
    public HuffmanNode getLeftChild(){
        return leftChild;
    }
    //gets the right child
    public HuffmanNode getRightChild(){
        return rightChild;
    }
    //sets the left child
    public void setLeftChild(HuffmanNode leftChild){
        this.leftChild = leftChild;
    }
    //sets the rgiht child
    public void setRightChild(HuffmanNode rightChild){
        this.rightChild = rightChild;
    }
}
