//these are my imported files
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
//this is a classed to compress the file uses reference to Huffman Node class
public class HuffmanCompressor {
    //this is the value of the input text file
    public static String inputString = "";
    //this is the first hashmap used
    public static HashMap<Character, Integer> OriginalHashmap = new HashMap<>();
    //this is the second hashmap that is created after the tree is used to encode the program
    public static HashMap<Character, String> StringValue = new HashMap<>();
    /**
     * this is hahsmamp that takes and input file and creates a hashmap with a character key value and a frequency
     * @param a2 input file that is used
     * @return the hashmap for this function is used
     * @throws FileNotFoundException
     */
    public static HashMap FileInputScan(String a2) throws FileNotFoundException {
        inputString = a2;
        File file = new File(a2);
        Scanner scan = new Scanner(file);
        StringBuilder s = new StringBuilder();
        while (scan.hasNext()) {
            s.append(scan.nextLine());
        }
        //this is code is code inspired from https://www.w3schools.com/java/java_hashmap.asp pretty similar code but I don't thi thier is another way to create that hashmap
        HashMap<Character, Integer> hashMapOfFrequency = new HashMap<>();
        char[] strArray = s.toString().toCharArray();
        for (int i = 0; i < strArray.length - 1; i++) {
            if (hashMapOfFrequency.containsKey(strArray[i])) {
                hashMapOfFrequency.put(strArray[i], hashMapOfFrequency.get(strArray[i]) + 1);
            } else {
                hashMapOfFrequency.put(strArray[i], 1);
            }
        }
        //this sets my main hashmpa equal to the other hashma
        OriginalHashmap = hashMapOfFrequency;
        return hashMapOfFrequency;
    }
    //I decided to use an arraylist because I enjoy using the arraylist more the linked list also seemed difficult to set the new front were I could jsut take the first two elelmetns and compare them in the arra

    /**
     * This is method that is used in order to turn a hashmap into an ordered array where the first values are the least frequently used
     * @return this is used to return the arraylist
     * @throws FileNotFoundException if the file that we used originally isn't found
     */
    public ArrayList<HuffmanNode> ArrayListOfNodes() throws FileNotFoundException {
        //I used a temporary hashmap where I messed with the values
        HashMap<Character, Integer> tempHashMap = new HashMap<Character, Integer>();
        tempHashMap = FileInputScan(inputString);
        //I iterated thorught he whole hashmap and organized it
        ArrayList<HuffmanNode> myArrayList = new ArrayList<HuffmanNode>(FileInputScan(inputString).size());
        //https://javatutorial.net/java-iterate-hashmap-example this is where the code was inspired from
        for (int i = 0; i < FileInputScan(inputString).size(); i++) {
            Iterator<HashMap.Entry<Character, Integer>> it = tempHashMap.entrySet().iterator();
            Character tempValueChar = ' ';
            Integer tempValueInteger = 100000000;
            //this is an iterator that is used in order to get the larger value then put the smallest one in next
            while (it.hasNext()) {
                boolean firstIteration = false;
                if (firstIteration = false) {
                    Map.Entry<Character, Integer> pair = it.next();
                    Character tempValueChar1 = pair.getKey();
                    Integer tempValueInteger1 = pair.getValue();
                    Map.Entry<Character, Integer> pair2 = it.next();
                    Character tempValueChar2 = pair.getKey();
                    Integer tempValueInteger2 = pair.getValue();
                    if (tempValueInteger1 >= tempValueInteger2) {
                        tempValueInteger = tempValueInteger2;
                        tempValueChar = tempValueChar2;
                        firstIteration = true;
                    } else {
                        tempValueInteger = tempValueInteger1;
                        tempValueChar = tempValueChar1;
                        firstIteration = true;
                    }
                }
                if (firstIteration = true) {
                    Map.Entry<Character, Integer> pair3 = it.next();
                    Character tempValueChar3 = pair3.getKey();
                    Integer tempValueInteger3 = pair3.getValue();
                    if (tempValueInteger > tempValueInteger3) {
                        tempValueInteger = tempValueInteger3;
                        tempValueChar = tempValueChar3;
                    }
                }
            }
            HuffmanNode Node = new HuffmanNode(tempValueChar, tempValueInteger, null, null);
            myArrayList.add(i, Node);
            tempHashMap.remove(tempValueChar);
        }
        return myArrayList;
    }

    /**
     * this is used to merege two noes
     * @param node1 sums node1
     * @param node2 sums node2
     * @return returns the parent node the sum of the two nodes with the left and right child pointed formt eh top
     */
    public HuffmanNode mergeHuffmanNodes(HuffmanNode node1, HuffmanNode node2) {
        return new HuffmanNode('|', node1.getFrequency() + node2.getFrequency(), node1, node2);
    }
    /**
     * This is used to gereate the tree the junk stored in each tree is the character J
     * @return it returns the top of the tree
     * @throws FileNotFoundException
     */
    public HuffmanNode generateHuffmanTre() throws FileNotFoundException {
        ArrayList<HuffmanNode> a1 = new ArrayList();
        int y = ArrayListOfNodes().size();
        a1 = ArrayListOfNodes();
        HuffmanNode tempMerge = null;
        int x = 0;
        while (x < y - 2) {
            HuffmanNode tempL = a1.get(0);
            HuffmanNode tempR = a1.get(1);
            tempMerge = mergeHuffmanNodes(tempL, tempR);
            a1.remove(0);
            a1.remove(0);
            int positionToPutIn = 0;
            while (tempMerge.getFrequency() > a1.get(positionToPutIn).getFrequency() && positionToPutIn + 1 < a1.size()) {
                positionToPutIn = positionToPutIn + 1;
            }
            if (positionToPutIn + 1 == a1.size()) {
                a1.add(positionToPutIn + 1, tempMerge);
            } else {
                a1.add(positionToPutIn, tempMerge);
            }
            x++;
        }
        HuffmanNode tempL = a1.get(0);
        HuffmanNode tempR = a1.get(1);
        tempMerge = mergeHuffmanNodes(tempL, tempR);
        return tempMerge;
    }
    /**
     * This is used to return the table in the system.out.print it also returns the tree bit savings and adds the codes to a hashtable to create the final document
     * @param root takes the top o fthe tree
     * @param keyVal This creates the key for the tree
     */
    public static void EncodingHelper(HuffmanNode root, String keyVal) {
        String a1 = "";
        if (root != null) {
            if (root.getLeftChild() != null)
                EncodingHelper(root.getLeftChild(), keyVal + "0");
            if (root.getRightChild() != null)
                EncodingHelper(root.getRightChild(), keyVal + "1");
            if (root.getLeftChild() == null && root.getRightChild() == null)
                a1 = root.getChar() + ":" + root.getFrequency() + ":" + keyVal + "\n";
            StringValue.put(root.getChar(), keyVal);
            System.out.print(a1);
        }
    }

    /**
     * this is used in order to output the file and the savings from the file. This also writes a file of 1's and 0's
     * @param outPutFile this is the name of the output file that the use wants
     * @return this returns the space saving of the file
     * @throws IOException
     */
    public static int outPutFile(String outPutFile) throws IOException {
        File file = new File(inputString);
        Scanner scan = new Scanner(file);
        StringBuilder s = new StringBuilder();
        StringBuilder sb2 = new StringBuilder();
        while (scan.hasNext()) {
            s.append(scan.nextLine());
        }
        int length = s.length() * 8;
        for (int i = 0; i < s.length(); i++) {
            sb2.append(StringValue.get(s.charAt(i)));
        }
        FileWriter myWriter = new FileWriter(outPutFile);
        myWriter.write(sb2.toString());
        return length - sb2.length();
    }

    /**
     * this is a main method that takes a file input and names the file output
     * @param args [0]is the input file location [2]is the output file
     * @throws IOException if file isn't found
     */
    public static void main(String[] args) throws IOException {
        args = new String[2];
        // write your code here
        //This can be changed in order to change File output name and the file that should be inserted using the command prompt
        //args[0]= "/Users/michaelfitzgerald/IdeaProjects/HuffmanCompressor/ShortStroyPoe.txt";
        //args[1]= "HuffmanEncodedFile";
        inputString = args[0];
        HuffmanCompressor a1 = new HuffmanCompressor();
        a1.ArrayListOfNodes();
        a1.generateHuffmanTre();
        EncodingHelper(a1.generateHuffmanTre(), "");
        String a21 = "The number Of BitsSaved is";
        System.out.print(a21 + " " + outPutFile(args[1]));
    }
}
