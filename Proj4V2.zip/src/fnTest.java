import java.io.*;
import java.util.Random;
import java.util.Scanner;

class fnTest {
    //}
    public static void main(String args[]) throws IOException {
        args = new String[2];
        fnTest a1 = new fnTest();
        a1.runTimeAnalysis();
        Sorting a2 = new Sorting();
        int[] arrayList;
        //arrayList = a2.mergeSort(fileScanner("/Users/michaelfitzgerald/Documents/dataP4.txt"));
        arrayList = a2.mergeSort(fileScanner(args[0]));
        StringBuilder sb = new StringBuilder();
        for(int i =0; i< arrayList.length; i++){
            sb.append(arrayList[i]);
            sb.append("\n");
        }
        //BufferedWriter writer = new BufferedWriter(new FileWriter("OutputFile"));
        BufferedWriter writer = new BufferedWriter(new FileWriter(args[1]));
        writer.write(sb.toString());
        writer.close();
    }

    /**
     * This is my scanner
     *
     * @param inputFile take a string as an input file puts everything to an array of ints for the sort method to work on
     */
    public static int[] fileScanner(String inputFile) throws FileNotFoundException {
        File file = new File(inputFile);
        //this is used to scane the document
        Scanner scan = new Scanner(file);
        //builds a string for the scanner
        int[] arrayOne = new int[10];
        int i = 0;
        //while loop used to scane whole document
        while (scan.hasNext()) {
        arrayOne[i] = Integer.parseInt(scan.nextLine());
        i++;
        }
        return arrayOne;
    }

    /**
     * This creates the runtime analysis
     */
    public static void runTimeAnalysis() {
        int x = 1;
        long a = 0;
        long b = 0;
        long c = 0;
        int m = 0;
        long[] medianValues = new long[4];
        int[] arrayForTest = new int[0];
        //does a loop for each size 3 times
        while (x < 13) {
            if (x < 3) {
                arrayForTest = new int[250000];
            } else if (x >= 4 && x < 7) {
                arrayForTest = new int[500000];
            } else if (x >= 7 && x < 10) {
                arrayForTest = new int[1000000];
            } else if (x >= 10 && x < 13) {
                arrayForTest = new int[1250000];
            }
            Random randNums = new Random();
            //this is used to create the random array
            for (int i = 0; i < arrayForTest.length - 1; i++) {
                arrayForTest[i] = randNums.nextInt();
            }
            //this calls the sorting method
            Sorting a1 = new Sorting();
            long startTime = System.nanoTime();
            //calls my array
            a1.mergeSort(arrayForTest);
            long estimatedTime = System.nanoTime() - startTime;
            //this just is used to determine teh average of the tree valeus and record tehm
            if (x % 3 == 2) {
                a = estimatedTime;
            } else if (x % 3 == 1) {
                b = estimatedTime;
            } else if (x % 3 == 0) {
                c = estimatedTime;
                //values of averages are added to a table
                medianValues[m] = (a + b + c) / 3;
                m = m + 1;
            }
            x = x + 1;
        }
        //prints a table of the times.
        for (int k = 0; k < medianValues.length; k++) {
            System.out.println(medianValues[k]);
        }
    }
}
