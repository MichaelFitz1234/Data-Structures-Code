public class Sorting {
    /**
     * This creates merge sort algorithm
     * @param arr Takes in an array
     * I returned the sorted array for the test method it was void but it was easier to return an array
     */
    public static int[] mergeSort(int[] arr) {
        //this is the temporary array that is flipped back and forth
        int[] temp = new int[arr.length];
        int iterations = 0;
        int leftStart;
        int numberOfMerges =10;
        int stepSize = 0;
        //used to determine the number of elemetns
        int numOfElements = arr.length;
        //this is used to determine which array is empty and which is being copied too
        boolean tempArray = false;
        //while loop used to loop through the vode
        while (numberOfMerges>1) {
            //the baseline nubmer of merges
            numberOfMerges = numOfElements / 2;
            stepSize = (int) Math.pow(2, iterations);
            leftStart = 0;
            //changes which array to copy to
            if (tempArray == false) {
                temp = new int[arr.length];
                for (int i = 1; i < numberOfMerges; i++) {
                    //this the merg being called for the number of merges
                    mergeHelper(arr, temp, leftStart, (leftStart + (stepSize - 1)), (leftStart + stepSize), (leftStart + (2 * stepSize) - 1));
                    leftStart += stepSize * 2;
                }
                //this checks for merging the last merge if the amount is even you just merge to the end
                if (numOfElements % 2 == 0) {
                    mergeHelper(arr, temp, leftStart, (leftStart + (stepSize - 1)), (leftStart + stepSize), (arr.length - 1));
                    stepSize = (int) Math.pow(2, iterations) * 2;

                } else {
                    //if the number of element is odd merge one more time
                    mergeHelper(arr, temp, leftStart, (leftStart + (stepSize - 1)), (leftStart + stepSize), (leftStart + (2 * stepSize) - 1));
                    //this is the only backCopying in my code this back copies only the size of one of the merges it's the least amount of back copying I found
                    for (int i = leftStart; i < (leftStart + (2 * stepSize)); i++) {
                        arr[i] = temp[i];
                        temp[i] = 0;
                    }
                    //This is used to merge the last merge with the last end group of elements
                    mergeHelper(arr, temp, leftStart, (leftStart + (2 * stepSize) - 1), (leftStart + (2 * stepSize)), (arr.length - 1));
                    //this is used for end condition reset at the start of loop
                    stepSize = (int) Math.pow(2, iterations) + Math.abs(leftStart + stepSize - (arr.length - 1));
                }
                //makes the stepsize greater
                stepSize = stepSize + 1;
                //the number of iterations so the stepsize increatsed
                iterations = iterations + 1;
                //this tells the number of elemetns in the array
                numOfElements = numOfElements / 2;
                tempArray = true;
                //same code just flipped
            } else {
                arr = new int[temp.length];
                for (int i = 1; i < numberOfMerges; i++) {
                    mergeHelper(temp, arr, leftStart, (leftStart + (stepSize - 1)), (leftStart + stepSize), (leftStart + (2 * stepSize) - 1));
                    leftStart += stepSize * 2;
                }
                if (numOfElements % 2 == 0) {
                    mergeHelper(temp, arr, leftStart, (leftStart + (stepSize - 1)), (leftStart + stepSize), (arr.length - 1));
                    stepSize = (int) Math.pow(2, iterations) * 2;

                } else {
                    mergeHelper(temp, arr, leftStart, (leftStart + (stepSize - 1)), (leftStart + stepSize), (leftStart + (2 * stepSize) - 1));
                    for (int i = leftStart; i < (leftStart + (2 * stepSize)); i++) {
                        temp[i] = arr[i];
                        arr[i] = 0;
                    }
                    mergeHelper(temp, arr, leftStart, (leftStart + (2 * stepSize) - 1), (leftStart + (2 * stepSize)), (arr.length - 1));
                    stepSize = (int) Math.pow(2, iterations) + Math.abs(leftStart + stepSize - (arr.length - 1));
                }
                stepSize = stepSize + 1;
                iterations = iterations + 1;
                numOfElements = numOfElements / 2;
                tempArray = false;
            }
        }
        if(tempArray == true){
            return temp;
        }else{
            return arr;
        }
    }

    /**
     * This is a mergeHelper method
     * @param arr takes an array
     * @param temp this is a temporary array
     * @param leftStart left begginig of the array
     * @param leftEnd left end of the array
     * @param rightStart right starts of the array within the array
     * @param rightEnd right end of the array
     */
    public static void mergeHelper(int[] arr, int[] temp, int leftStart, int leftEnd, int rightStart, int rightEnd) {
        int i = leftStart;
        int j = rightStart;
        int k = leftStart;
        //This to merge the values by having an i and j
        while (i != leftEnd + 1 && j != rightEnd + 1) {
            if (arr[i] > arr[j]) {
                //if the value is bigger than the other the we add the smaller elemet ot eh arra
                temp[k] = arr[j];
                j = j + 1;
                k = k + 1;
                //this is the else for the same process
            } else {
                temp[k] = arr[i];
                i = i + 1;
                k = k + 1;
            }
        }
        //this puts the rest of the array into the temp array
        if (i == leftEnd + 1) {
            for (int x = j; x < rightEnd + 1; x++) {
                temp[k] = arr[x];
                k = k + 1;
            }
        } else {
            //this puts the rest of the other array into the end of the array
            for (int x = i; x < leftEnd + 1; x++) {
                temp[k] = arr[x];
                k = k + 1;
            }
        }
    }
}
