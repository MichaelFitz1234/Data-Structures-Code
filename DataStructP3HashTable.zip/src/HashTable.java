public class HashTable {
    //this is variable used to determine the number of slots the array has taken
    private static float spacesTaken = 0;
    //starts small to show resize works but the original array that is created
    private static Entry[] hashTable = new Entry[10];
    /**Method is used to insert strings into the hashtable
     * This creates a hashcode for the string which is an index at the table if the value of the value at the index is the same as on open case it adds the index to a linked list
     * @param keyValue takes a string which is the input word and adds it to the hashtable
     */
    public static void insert(String keyValue) {
        //this creates a Entry node
        Entry a1 = null;
        //index at whic to add teh entry nod
        int index = Math.abs(keyValue.hashCode()) % hashTable.length;
        //this adds the node to hte hashtable
        Entry someNode = hashTable[index];
        //checks if the position is empty if so adds it to the table
        if (someNode == null) {
            someNode = new Entry(keyValue, 1, null);
            hashTable[index] = someNode;
            //used to calculate the load factor ratio of open to unopen spots in the array tell if needs to be reszied
            spacesTaken = spacesTaken + 1;
            //then looks athte position and adds teh value as the next value in hte linked list
        } else {
            while (someNode != null) {
                //this checks if the nodes have the same key value if so you add one to the frequency of the node and end the method
                if (helperMethod(keyValue, someNode)) {
                    someNode.addOne();
                    return;
                } else {
                    if (!someNode.hasNext()) {
                        a1 = someNode;
                    }
                    someNode = someNode.getNext();
                }
            }
            Entry NewNode = new Entry(keyValue, 1, null);
            a1.setNext(NewNode);

        }
    }

    /**
     * used to compare if two nodes are teh same
     * @param keyVal this compares the string value of one node
     * @param someNode this is used to compare the key value of the other to add one to the frequency
     * @return It returns true if their the same and false if their not the same string
     */
    public static boolean helperMethod(String keyVal, Entry someNode) {
        return keyVal.equals(someNode.getKeyValue());
    }

    /**
     * This calculates the load factor lambda its the ratio of taken spots in the array to open spots
     * @return it returns true if we have space and not if we don;t
     */
    public boolean hasSpace() {
        float lambda = spacesTaken / (float) hashTable.length;
        return !(lambda >= .75);
    }

    /**
     * This is used to reaize the array
     */
    public void resize() {
        //creates a new tempary array twice the size of the other array
        Entry[] temp = new Entry[hashTable.length * 2];
        //loops through every elemetn in the array
        for (int i = 0; i < hashTable.length; i++) {
            //finds any value in the array that isn't null
            while (hashTable[i] != null) {
                //then it checks if their is a linked list there and itterates through that
                String tempKey = hashTable[i].getKeyValue();
                int tempInt = hashTable[i].numberOfOccurances();
                //cretaes a new index for the element in the updated arra
                int index = Math.abs(tempKey.hashCode()) % temp.length;
                Entry someNode = temp[index];
                Entry a1 = null;
                //does an insert method to add it to the temporary array
                if (someNode == null) {
                    someNode = new Entry(tempKey, tempInt, null);
                    temp[index] = someNode;
                } else {
                    while (someNode != null) {
                        if (!someNode.hasNext()) {
                            a1 = someNode;
                        }
                        someNode = someNode.getNext();
                    }
                    //adds the element to the array eventulaly similar to insert method written above
                    Entry NewNode = new Entry(tempKey, tempInt, null);
                    a1.setNext(NewNode);
                    someNode = a1;
                }
                hashTable[i] = hashTable[i].getNext();
            }
        }
        //once the whole hashtable is trasnfered to the larger temporry array the hashtable from before becomes the temporary larger array
        hashTable = temp;
    }

    /**
     * this is used to loop through the arrray and print every eleemt
     * @return this returns as string which is the array
     */
    public String returnHashTable() {
        StringBuilder sb = new StringBuilder();
        float x;
        //this goes through every element in hte hashtable
        for (int i = 0; i < hashTable.length; i++) {
            //if the element isn't null then it is looked at
            while (hashTable[i] != null) {
                //loop runs while the linked list is iterated through
                sb.append("(");
                sb.append(hashTable[i].getKeyValue());
                sb.append(" ");
                sb.append(hashTable[i].numberOfOccurances());
                sb.append(")");
                sb.append(" ");
                hashTable[i] = hashTable[i].getNext();
                //when each linked list is fully looked at we move to the next none null elelmetn
            }
        }
        x = 1/(spacesTaken / (float) hashTable.length);
        sb.append("\n");
        sb.append("The frequency of collision of a occupied element in the array is " + x + " spots traveled for each collision encountered");
        //This is the frequency of collion based on the number of occupied spots in the array
        //this returns the stirng of every element in the hashtable
        return sb.toString();
    }

    /**
     * The nested class of each key and value
     */
    private static class Entry {
        String key;
        int valOfOccurances;
        Entry nextEntry;

        /**
         * Constructor
         * @param key this is the string key
         * @param valOfOccurances the number of occurences of each word
         * @param nextEntry This is the pointing node for the linked list that is created
         */
        Entry(String key, int valOfOccurances, Entry nextEntry) {
            this.key = key;
            this.valOfOccurances = valOfOccurances;
            this.nextEntry = nextEntry;
        }

        /**
         * This is an itterator
         * @return returns if the method has a next value
         */
        private boolean hasNext() {
            return this.getNext() != null;
        }

        /**
         * This gets the next node in the linked list
         * @return return the next node
         */
        private Entry getNext() {
            return this.nextEntry;
        }
        /**
         * Sets the next node the the current node is pointing to
         * @param nextNode takes in a node
         */
        private void setNext(Entry nextNode) {
            this.nextEntry = nextNode;
        }

        /**
         * this get the stirng key value
         * @return this returns the key value
         */
        private String getKeyValue() {
            return this.key;
        }

        /**
         * used to add to the freuqency if the key values are the same
         */
        private void addOne() {
            this.valOfOccurances = valOfOccurances + 1;
        }

        /**
         * The data of the hastable the frequency of hte word
         * @return and integer the frequeny of hte word
         */
        private int numberOfOccurances() {
            return this.valOfOccurances;
        }
    }
}
