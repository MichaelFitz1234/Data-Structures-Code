import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class wordCount {
    //can only do one hashtalbe
    private HashTable hashTable = new HashTable();
    /**
     * This is method that is used to create a hashtable that shows the frequencies of characters and creates a file that tells the frequency of each word and numbe of occurences
     * @param inputFile This is an inputFile path that is a tet file
     * @throws IOException THis is an exceptino if the user doesn't input a valid file path
     */
    public void Scanner(String inputFile) throws IOException {
        //this creates the hashtable
        //creates a file for the scanner
        File file = new File(inputFile);
        //this is used to scane the document
        Scanner scan = new Scanner(file);
        //builds a string for the scanner
        StringBuilder ScannedFile = new StringBuilder();
        //while loop used to scane whole document
        while (scan.hasNext()) {
            ScannedFile.append(scan.nextLine());
            ScannedFile.append(" ");
        }
        //creates an array of characters from the input file
        char[] strArray = ScannedFile.toString().toCharArray();
        int k = 0;
        StringBuilder thisString = new StringBuilder();
        //this is used to check if the word is part of the alphabet or if their is a break if so it knows thier is a next word
        for (int i = 0; i < strArray.length; i++) {
            //this puts the strings to a lower case so Father and father are the same
            strArray[i] = Character.toLowerCase(strArray[i]);
            //if in the range their the same while their the same it builds a string
            if (96 < strArray[i] && strArray[i] < 123) {
                thisString.append(strArray[i]);
                k++;
            } else if (thisString.length() > 0) {
                //checks if the aray needs to be resized after every word is added
                if (!hashTable.hasSpace()) {
                    //this resizes the array
                    hashTable.resize();
                }
                //when the if statement is false it adds the built string to thte hashmap and deletes teh string so it can deep adding strings
                HashTable.insert(thisString.toString());
                thisString.delete(0, k);
                k = 0;
            }
        }
    }

    /**
     * This is the output file writer written based off of https://www.baeldung.com/java-write-to-file
     * @param fileName this returns the filename
     * @throws IOException throws if the file doesn't exist.
     */
    public void outPutFile(String fileName)
            throws IOException {
        String str = hashTable.returnHashTable();
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
        writer.write(str);
        writer.close();
    }
    //main method takes two args the first is the file path second is the location I commented out code to write to the toy and other file
    public static void main(String[] args) throws IOException {
        wordCount ArrayOfStrings = new wordCount();
        //ArrayOfStrings.Scanner("/Users/michaelfitzgerald/Desktop/dataStructToy.txt");
        //ArrayOfStrings.outPutFile("OutputOfToyFile");
        //ArrayOfStrings.Scanner("/Users/michaelfitzgerald/Documents/ShortStroyPoe.txt");
        //ArrayOfStrings.outPutFile("OutputOfTestFile");
        args = new String[2];
        ArrayOfStrings.Scanner(args[0]);
        ArrayOfStrings.outPutFile(args[1]);
    }

}